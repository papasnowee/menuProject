export { default } from './Tabs'
