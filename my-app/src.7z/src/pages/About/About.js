import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class About extends Component {
  static propTypes = {
    prop: PropTypes,
  }

  render() {
    return <div>о нас</div>
  }
}
