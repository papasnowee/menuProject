import history from './history'

export { default } from './routes'
export { history }
