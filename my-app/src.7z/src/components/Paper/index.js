export { default } from './Paper'
