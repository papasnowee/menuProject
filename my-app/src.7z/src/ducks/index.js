import { combineReducers } from 'redux-immutable'
import news from './news'

export default combineReducers({
  news,
})
